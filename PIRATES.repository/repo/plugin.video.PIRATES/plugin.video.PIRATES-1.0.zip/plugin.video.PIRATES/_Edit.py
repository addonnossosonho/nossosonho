import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/addonnossosonho/nossosonho/master/entrada'
addon = xbmcaddon.Addon('plugin.video.PIRATES')